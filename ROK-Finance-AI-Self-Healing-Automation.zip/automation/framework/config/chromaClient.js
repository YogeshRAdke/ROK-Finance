const { ChromaClient } = require('chromadb');
const env = require('./env');

let client = null;

function getChromaClient() {
  if (!client) client = new ChromaClient({ path: env.chromaUrl });
  return client;
}

module.exports = { getChromaClient };
