const OpenAI = require('openai');
const env = require('./env');

let client = null;

function getClient() {
  if (env.aiMode === 'mock') return null;
  if (!env.openaiApiKey) throw new Error('OPENAI_API_KEY is not set. Set AI_MODE=mock to run without OpenAI.');
  if (!client) client = new OpenAI({ apiKey: env.openaiApiKey });
  return client;
}

module.exports = { getClient };
