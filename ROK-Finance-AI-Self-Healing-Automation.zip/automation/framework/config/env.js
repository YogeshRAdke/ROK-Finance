const dotenv = require('dotenv');

dotenv.config();

function required(name) {
  const val = process.env[name];
  if (!val) throw new Error(`Missing required env var: ${name}`);
  return val;
}

module.exports = {
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  aiMode: (process.env.AI_MODE || 'live').toLowerCase(),

  chromaUrl: process.env.CHROMA_URL || 'http://localhost:8000',
  chromaCollection: process.env.CHROMA_COLLECTION || 'ui_memory',

  confidenceThreshold: Number(process.env.HEALING_CONFIDENCE_THRESHOLD || 0.65),
  maxRetries: Number(process.env.HEALING_MAX_RETRIES || 3),
  backoffMs: Number(process.env.HEALING_BACKOFF_MS || 350),

  domMaxChars: Number(process.env.DOM_MAX_CHARS || 12000),

  logLevel: process.env.LOG_LEVEL || 'info',
};
