const { generateLocator } = require('./aiLocatorService');

module.exports = {
  generateLocator,
};
