const env = require('../config/env');
const { getClient } = require('../config/openaiClient');
const logger = require('../utils/logger');
const { buildPrompt } = require('./promptBuilder');
const { guessFromIntent } = require('./heuristicLocator');

async function generateLocator({ failedLocator, snapshot, memoryHits, intent }) {
  if (env.aiMode === 'mock') {
    return {
      locator: guessFromIntent(intent, snapshot.html),
      meta: { model: 'mock-heuristic', tokens: 0 },
    };
  }

  const client = getClient();
  const prompt = buildPrompt({ failedLocator, snapshot, memoryHits, intent });

  const model = 'gpt-4o-mini';
  const res = await client.chat.completions.create({
    model,
    messages: [
      { role: 'system', content: 'You generate stable Playwright locators.' },
      { role: 'user', content: prompt },
    ],
    temperature: 0.1,
  });

  const locator = (res.choices?.[0]?.message?.content || '').trim();
  logger.aiEvent({ prompt, response: locator, model, tokens: res.usage?.total_tokens });

  return {
    locator,
    meta: { model, tokens: res.usage?.total_tokens || 0 },
  };
}

module.exports = { generateLocator };
