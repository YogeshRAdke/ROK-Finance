function buildPrompt({ failedLocator, snapshot, memoryHits, intent }) {
  const memoryText = (memoryHits || [])
    .slice(0, 5)
    .map((m, i) => `#${i + 1} similarity=${m.similarity}\nFAILED=${m.failedLocator}\nHEALED=${m.healedLocator}`)
    .join('\n\n');

  const a11y = snapshot.a11y ? JSON.stringify(snapshot.a11y).slice(0, 6000) : '';

  return `You are an expert Playwright locator generator for enterprise insurance web apps.

TASK:
Return ONLY ONE locator using the following safe Locator DSL:
- testid=<value>
- role=<role>[name="..."]
- label=<text>
- placeholder=<text>
- text=<text>
- css=<selector>

RULES:
- Prefer role=... with accessible name first.
- Prefer testid=... when data-testid exists.
- Avoid XPath.
- Avoid nth-child.
- Avoid unstable auto-generated classes.
- Prefer stable attributes: data-testid, aria-label, name, placeholder, role.
- Produce a locator that likely matches exactly 1 element.

CONTEXT:
Intent: ${intent || 'N/A'}
URL: ${snapshot.url}
Title: ${snapshot.title}

FAILED LOCATOR:
${failedLocator}

HISTORICAL MEMORY (most similar patterns):
${memoryText || 'None'}

ACCESSIBILITY TREE (semantic view):
${a11y || 'Not available'}

HTML (truncated):
${snapshot.html}

OUTPUT:
Return only the locator line. No explanation.
`;
}

module.exports = { buildPrompt };
