/**
 * Heuristic fallback when AI_MODE=mock or OpenAI is unavailable.
 * Attempts to infer a stable locator from the DOM snapshot.
 */

function extractTestIds(html) {
  const matches = [];
  const re = /data-testid\s*=\s*['"]([^'"]+)['"]/gi;
  let m;
  while ((m = re.exec(html))) matches.push(m[1]);
  return matches;
}

function guessFromIntent(intent, html) {
  const lower = (intent || '').toLowerCase();
  const testIds = extractTestIds(html);
  // naive mapping by keywords
  const candidate = testIds.find((t) => lower.includes(t.toLowerCase().replace(/[-_]/g, ' ')));
  if (candidate) return `testid=${candidate}`;

  // try common patterns
  if (lower.includes('login') || lower.includes('sign in')) {
    const loginBtn = testIds.find((t) => /login|sign-in|signin/i.test(t));
    if (loginBtn) return `testid=${loginBtn}`;
  }

  // fallback to role button with common name
  if (lower.includes('click') || lower.includes('submit')) return 'role=button[name="Submit"]';
  return 'css=body';
}

module.exports = { guessFromIntent };
