const env = require('../config/env');
const { getChromaClient } = require('../config/chromaClient');
const { embed } = require('./aiEmbeddingService');
const { uuidv4 } = require('../utils/uuid');

async function getCollection() {
  const client = getChromaClient();
  return await client.getOrCreateCollection({ name: env.chromaCollection });
}

function buildEmbeddingText(snapshot, intent) {
  const a11y = snapshot.a11y ? JSON.stringify(snapshot.a11y).slice(0, 6000) : '';
  return `URL=${snapshot.url}\nTITLE=${snapshot.title}\nINTENT=${intent || ''}\nA11Y=${a11y}\nHTML=${snapshot.html}`;
}

async function embedSnapshot(snapshot, intent) {
  const text = buildEmbeddingText(snapshot, intent);
  return await embed(text);
}

async function search(queryEmbedding) {
  const collection = await getCollection();
  const res = await collection.query({ queryEmbeddings: [queryEmbedding], nResults: 5 });

  const documents = (res.documents && res.documents[0]) || [];
  const distances = (res.distances && res.distances[0]) || [];

  // Convert distance to similarity (best-effort)
  const hits = documents.map((doc, i) => {
    let parsed = {};
    try { parsed = JSON.parse(doc); } catch { parsed = { raw: doc }; }
    const dist = distances[i];
    const similarity = typeof dist === 'number' ? Math.max(0, 1 - dist) : 0.5;
    return { ...parsed, similarity };
  });

  return hits;
}

async function storeLearning({ snapshot, intent, failedLocator, healedLocator, confidence, aiMeta }) {
  const collection = await getCollection();
  const embedding = await embedSnapshot(snapshot, intent);

  const doc = {
    url: snapshot.url,
    title: snapshot.title,
    intent,
    failedLocator,
    healedLocator,
    confidence,
    ai: aiMeta,
    timestamp: snapshot.timestamp,
  };

  await collection.add({
    ids: [uuidv4()],
    embeddings: [embedding],
    documents: [JSON.stringify(doc)],
  });
}

module.exports = { embedSnapshot, search, storeLearning };
