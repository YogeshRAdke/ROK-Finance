const { getClient } = require('../config/openaiClient');
const env = require('../config/env');

async function embed(text) {
  if (env.aiMode === 'mock') {
    // deterministic pseudo-embedding for offline runs
    const hash = Array.from(String(text)).reduce((a, c) => (a + c.charCodeAt(0)) % 997, 0);
    return Array.from({ length: 64 }, (_, i) => ((hash + i * 13) % 101) / 100);
  }

  const client = getClient();
  const res = await client.embeddings.create({
    model: 'text-embedding-3-large',
    input: text,
  });
  return res.data[0].embedding;
}

module.exports = { embed };
