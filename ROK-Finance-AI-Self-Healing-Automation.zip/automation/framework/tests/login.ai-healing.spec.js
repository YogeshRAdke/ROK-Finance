const { test, expect } = require('@playwright/test');
const { smartFill, smartClick } = require('../actions/smartActions');

/**
 * Demo test:
 * - Builds a small login page in-memory.
 * - Intentionally uses failing locators (old ids)
 * - Healing should recover using role/testid and attach artifacts to Allure.
 */

test('AI self-healing login flow (dynamic locator failure demo)', async ({ page }, testInfo) => {
  const html = `
  <html>
    <head><title>Demo Login</title></head>
    <body>
      <main>
        <h1>Welcome</h1>
        <label for="user">Username</label>
        <input id="user" data-testid="username" placeholder="Enter username" />

        <label for="pass">Password</label>
        <input id="pass" data-testid="password" type="password" placeholder="Enter password" />

        <!-- Real locator is stable testid/role, but test uses outdated css selectors -->
        <button data-testid="login-button" aria-label="Login">Login</button>

        <p id="status" role="status"></p>

        <script>
          document.querySelector('[data-testid="login-button"]').addEventListener('click', () => {
            const u = document.querySelector('[data-testid="username"]').value;
            const p = document.querySelector('[data-testid="password"]').value;
            document.getElementById('status').innerText = (u && p) ? 'SUCCESS' : 'FAILED';
          });
        </script>
      </main>
    </body>
  </html>`;

  await page.setContent(html);

  await smartFill(page, 'css=#username_old', 'demoUser', { intent: 'fill username field', testInfo });
  await smartFill(page, 'css=#password_old', 'demoPass', { intent: 'fill password field', testInfo });

  const clickResult = await smartClick(page, 'css=#loginBtn_old', { intent: 'click login button', testInfo });

  await expect(page.getByRole('status')).toHaveText('SUCCESS');
  expect(clickResult.healed).toBeTruthy();
});
