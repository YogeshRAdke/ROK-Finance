const { runWithHealing } = require('../core/healingEngine');
const { create } = require('../core/locatorFactory');

async function smartClick(page, locator, options = {}) {
  const intent = options.intent || 'click';
  const actionName = 'smartClick';

  return await runWithHealing({
    page,
    actionName,
    locator,
    intent,
    testInfo: options.testInfo,
    actionFn: async (locText) => {
      const loc = create(page, locText);
      await loc.first().click({ timeout: options.timeout || 8000 });
    },
  });
}

async function smartFill(page, locator, value, options = {}) {
  const intent = options.intent || 'fill';
  const actionName = 'smartFill';

  return await runWithHealing({
    page,
    actionName,
    locator,
    intent,
    testInfo: options.testInfo,
    actionFn: async (locText) => {
      const loc = create(page, locText);
      await loc.first().fill(value, { timeout: options.timeout || 8000 });
    },
  });
}

async function smartSelect(page, locator, value, options = {}) {
  const intent = options.intent || 'select';
  const actionName = 'smartSelect';

  return await runWithHealing({
    page,
    actionName,
    locator,
    intent,
    testInfo: options.testInfo,
    actionFn: async (locText) => {
      const loc = create(page, locText);
      await loc.first().selectOption(value, { timeout: options.timeout || 8000 });
    },
  });
}

async function smartCheck(page, locator, checked = true, options = {}) {
  const intent = options.intent || (checked ? 'check' : 'uncheck');
  const actionName = 'smartCheck';

  return await runWithHealing({
    page,
    actionName,
    locator,
    intent,
    testInfo: options.testInfo,
    actionFn: async (locText) => {
      const loc = create(page, locText);
      if (checked) await loc.first().check({ timeout: options.timeout || 8000 });
      else await loc.first().uncheck({ timeout: options.timeout || 8000 });
    },
  });
}

module.exports = { smartClick, smartFill, smartSelect, smartCheck };
