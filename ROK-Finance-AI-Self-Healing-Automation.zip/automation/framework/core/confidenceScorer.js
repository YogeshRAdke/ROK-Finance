function clamp01(x) {
  return Math.max(0, Math.min(1, x));
}

/**
 * Confidence combines:
 * - vector similarity (0..1)
 * - validation uniqueness (prefer 1 match)
 * - heuristic bonus for stable types (role/testid)
 */
function score({ similarity = 0, matchCount = 1, locatorType = 'css' }) {
  const sim = clamp01(similarity);

  // uniqueness
  const unique = matchCount === 1 ? 1 : matchCount <= 3 ? 0.7 : 0.4;

  const stabilityBonus = locatorType === 'testid' ? 1 : locatorType === 'role' ? 0.9 : locatorType === 'label' ? 0.85 : 0.75;

  return clamp01(0.55 * sim + 0.30 * unique + 0.15 * stabilityBonus);
}

module.exports = { score };
