const { create } = require('./locatorFactory');

async function validate(page, locatorText, timeoutMs = 1500) {
  try {
    const loc = create(page, locatorText);
    await loc.first().waitFor({ timeout: timeoutMs });
    const count = await loc.count();
    // For stable healing we prefer unique or low-match selectors
    return { ok: count >= 1, count };
  } catch {
    return { ok: false, count: 0 };
  }
}

module.exports = { validate };
