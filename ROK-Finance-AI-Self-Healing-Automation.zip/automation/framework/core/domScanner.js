const env = require('../config/env');

async function scan(page) {
  const url = page.url();

  const html = await page.evaluate(() => document.documentElement.outerHTML);
  const clippedHtml = html.slice(0, env.domMaxChars);

  // Accessibility tree provides semantic understanding
  let a11y = null;
  try {
    a11y = await page.accessibility.snapshot({ interestingOnly: true });
  } catch {
    a11y = null;
  }

  // Useful metadata for AI
  const title = await page.title().catch(() => '');

  return {
    url,
    title,
    html: clippedHtml,
    a11y,
    timestamp: new Date().toISOString(),
  };
}

module.exports = { scan };
