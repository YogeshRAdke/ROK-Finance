const { parse } = require('./locatorParser');

function create(page, locatorText) {
  const spec = parse(locatorText);

  switch (spec.type) {
    case 'testid':
      return page.getByTestId(spec.value);
    case 'role':
      return page.getByRole(spec.role, spec.name ? { name: spec.name } : undefined);
    case 'label':
      return page.getByLabel(spec.value);
    case 'placeholder':
      return page.getByPlaceholder(spec.value);
    case 'text':
      return page.getByText(spec.value, { exact: false });
    case 'css':
    default:
      return page.locator(spec.value);
  }
}

module.exports = { create };
