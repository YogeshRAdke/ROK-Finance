const domScanner = require('./domScanner');
const { validate } = require('./validator');
const { parse } = require('./locatorParser');
const { score } = require('./confidenceScorer');
const retryEngine = require('./retryEngine');
const screenshotService = require('../utils/screenshotService');
const logger = require('../utils/logger');
const vectorMemory = require('../ai/vectorMemory');
const aiAgent = require('../ai/aiAgent');
const env = require('../config/env');

/**
 * Recover a locator at runtime.
 * Returns: { locator, confidence, meta }
 */
async function recover(page, failedLocator, intent = '') {
  const snapshot = await domScanner.scan(page);

  // Step 1: create embedding and search memory
  const embedding = await vectorMemory.embedSnapshot(snapshot, intent);
  const memoryHits = await vectorMemory.search(embedding);

  // Step 2: ask AI (or heuristics fallback)
  const aiResult = await aiAgent.generateLocator({
    failedLocator,
    snapshot,
    memoryHits,
    intent,
  });

  // Step 3: validate locator
  const validation = await validate(page, aiResult.locator, 2500);
  if (!validation.ok) {
    const screenshotPath = await screenshotService.capture(page, 'healing_validation_failed');
    logger.warn({ failedLocator, proposed: aiResult.locator, screenshotPath }, 'Healing validation failed');
    throw new Error(`Healing failed. AI locator did not match DOM: ${aiResult.locator}`);
  }

  // Step 4: compute confidence
  const locatorType = parse(aiResult.locator).type;
  const similarity = typeof memoryHits?.[0]?.similarity === 'number' ? memoryHits[0].similarity : 0.5;
  const confidence = score({ similarity, matchCount: validation.count, locatorType });

  if (confidence < env.confidenceThreshold) {
    const screenshotPath = await screenshotService.capture(page, 'healing_low_confidence');
    logger.warn({ failedLocator, healedLocator: aiResult.locator, confidence, screenshotPath }, 'Healing produced low confidence locator');
    throw new Error(`Healing confidence below threshold (${env.confidenceThreshold}). Locator: ${aiResult.locator}`);
  }

  // Step 5: store autonomous learning
  await vectorMemory.storeLearning({
    snapshot,
    intent,
    failedLocator,
    healedLocator: aiResult.locator,
    confidence,
    aiMeta: aiResult.meta,
  });

  return {
    locator: aiResult.locator,
    confidence,
    meta: { similarity, matchCount: validation.count, model: aiResult.meta.model, tokens: aiResult.meta.tokens },
  };
}

async function attachIfPossible(testInfo, name, body, contentType = 'application/json') {
  if (!testInfo || typeof testInfo.attach !== 'function') return;
  await testInfo.attach(name, { body, contentType });
}

/**
 * Runs an action with healing + retry.
 * Options:
 * - testInfo: Playwright testInfo for Allure attachments
 */
async function runWithHealing({ page, actionName, locator, intent, actionFn, testInfo }) {
  return retryEngine.retry(async (attempt) => {
    try {
      await actionFn(locator);
      return { locator, healed: false, attempt };
    } catch (err) {
      const screenshotPath = await screenshotService.capture(page, `${actionName}_failed_attempt_${attempt}`);
      logger.warn({ actionName, locator, attempt, screenshotPath, error: String(err) }, 'Action failed, attempting healing');

      const healed = await recover(page, locator, intent);

      await actionFn(healed.locator);

      const healingSummary = {
        url: page.url(),
        action: actionName,
        intent,
        failedLocator: locator,
        healedLocator: healed.locator,
        confidence: healed.confidence,
        meta: healed.meta,
        retryAttempt: attempt,
        screenshotPath,
      };

      logger.healingEvent(healingSummary);

      // Attach artifacts to Allure via Playwright attachments
      await attachIfPossible(testInfo, `healing-${actionName}-attempt-${attempt}.json`, Buffer.from(JSON.stringify(healingSummary, null, 2)));
      try {
        if (screenshotPath) {
          const fs = require('fs');
          if (fs.existsSync(screenshotPath)) {
            await attachIfPossible(testInfo, `healing-${actionName}-attempt-${attempt}.png`, fs.readFileSync(screenshotPath), 'image/png');
          }
        }
      } catch {
        // ignore attach failures
      }

      return { locator: healed.locator, healed: true, confidence: healed.confidence, attempt };
    }
  });
}

module.exports = { recover, runWithHealing };
