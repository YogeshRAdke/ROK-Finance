const env = require('../config/env');

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function retry(fn, opts = {}) {
  const retries = opts.retries ?? env.maxRetries;
  const backoff = opts.backoffMs ?? env.backoffMs;
  let lastErr;

  for (let i = 1; i <= retries; i++) {
    try {
      return await fn(i);
    } catch (e) {
      lastErr = e;
      if (i < retries) await sleep(backoff * i);
    }
  }
  throw lastErr;
}

module.exports = { retry };
