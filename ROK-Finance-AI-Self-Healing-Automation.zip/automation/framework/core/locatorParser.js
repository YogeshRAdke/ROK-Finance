/**
 * Locator DSL (safe, no eval):
 * - testid=<value>
 * - role=<role>[name="..."]
 * - label=<text>
 * - placeholder=<text>
 * - text=<text>
 * - css=<selector>
 *
 * Also accepts Playwright text selector like: text=Sign in
 */

function parse(locatorText) {
  const raw = String(locatorText || '').trim();
  const idx = raw.indexOf('=');

  if (idx === -1) {
    // treat as css by default
    return { type: 'css', value: raw };
  }

  const type = raw.slice(0, idx).trim();
  const rest = raw.slice(idx + 1).trim();

  if (type === 'role') {
    // role=button[name="Sign in"]
    const roleMatch = rest.match(/^([a-zA-Z]+)(\[name=("|')(.*?)("|')\])?$/);
    if (!roleMatch) return { type: 'css', value: raw };
    const role = roleMatch[1];
    const name = roleMatch[4];
    return { type: 'role', role, name };
  }

  if (['testid', 'label', 'placeholder', 'text', 'css'].includes(type)) {
    return { type, value: rest.replace(/^['"]|['"]$/g, '') };
  }

  // default
  return { type: 'css', value: raw };
}

module.exports = { parse };
