const { validate } = require('./validator');
const { create } = require('./locatorFactory');

async function waitFor(page, locatorText, timeout = 2000) {
  const loc = create(page, locatorText);
  await loc.first().waitFor({ timeout });
  return loc;
}

async function isHealthy(page, locatorText) {
  const res = await validate(page, locatorText, 1200);
  return res.ok;
}

module.exports = { waitFor, isHealthy };
