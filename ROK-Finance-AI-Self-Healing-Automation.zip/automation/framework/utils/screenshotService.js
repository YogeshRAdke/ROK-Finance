const path = require('path');
const { ensureDir } = require('./fileSystem');

module.exports = {
  async capture(page, name) {
    const dir = path.join(process.cwd(), 'framework', 'screenshots');
    ensureDir(dir);
    const filePath = path.join(dir, `${Date.now()}_${name}.png`);
    await page.screenshot({ path: filePath, fullPage: true });
    return filePath;
  },
};
