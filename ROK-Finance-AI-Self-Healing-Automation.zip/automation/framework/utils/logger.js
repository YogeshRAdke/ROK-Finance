const pino = require('pino');
const env = require('../config/env');

const logger = pino({
  level: env.logLevel,
  transport: process.env.CI
    ? undefined
    : {
        target: 'pino-pretty',
        options: { colorize: true, translateTime: 'SYS:standard' },
      },
});

function sanitize(text, max = 8000) {
  if (!text) return '';
  return String(text).slice(0, max);
}

module.exports = {
  info: (obj, msg) => logger.info(obj, msg),
  warn: (obj, msg) => logger.warn(obj, msg),
  error: (obj, msg) => logger.error(obj, msg),
  debug: (obj, msg) => logger.debug(obj, msg),

  healingEvent: (event) => {
    logger.info(
      {
        type: 'HEALING_EVENT',
        url: event.url,
        action: event.action,
        intent: event.intent,
        failedLocator: sanitize(event.failedLocator, 4000),
        healedLocator: sanitize(event.healedLocator, 4000),
        confidence: event.confidence,
        retryAttempt: event.retryAttempt,
        screenshotPath: event.screenshotPath,
      },
      'Self-healing applied'
    );
  },

  aiEvent: (event) => {
    logger.debug(
      {
        type: 'AI_EVENT',
        prompt: sanitize(event.prompt, 4000),
        response: sanitize(event.response, 4000),
        model: event.model,
        tokens: event.tokens,
      },
      'AI locator generation'
    );
  },
};
