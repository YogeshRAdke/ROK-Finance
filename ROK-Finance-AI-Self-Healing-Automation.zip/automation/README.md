# Playwright AI Self‑Healing Framework (Enterprise‑Grade)

> Production‑ready **autonomous AI self‑healing test automation framework** using **Playwright (JavaScript)** + **OpenAI** + **ChromaDB** + **Allure**.

**Last updated:** 2026-05-02

## ✨ Key Capabilities
- Runtime **locator healing** with retry + recovery
- AI locator generation (OpenAI) with strict stability rules
- **DOM semantic understanding** via Accessibility Tree snapshot
- Vector memory learning (OpenAI embeddings + ChromaDB)
- Persistent autonomous learning after successful healing
- Enterprise logging, screenshots, CI/CD ready
- npm package ready + GitHub ready

---

## ✅ Architecture Overview
### Healing Agent Workflow
1. Locator fails
2. Scan DOM (HTML + Accessibility Tree)
3. Create embedding
4. Search vector memory for similar UI patterns
5. AI generates a stable locator (prefers role/testid)
6. Validate locator + compute confidence score
7. Retry action
8. Persist learning back into ChromaDB

---

## 📁 Repository Structure
```
framework/
 ├── core/          # healing engine, validator, retry, DOM scanner
 ├── ai/            # OpenAI locator + embeddings, vector memory
 ├── actions/       # smartClick/smartFill/smartSelect/smartCheck
 ├── reports/       # Allure output target (gitkeep)
 ├── screenshots/   # captured artifacts (gitkeep)
 ├── config/        # env, OpenAI client, Chroma client
 ├── utils/         # logger, screenshot service
 └── tests/         # example tests
```

---

## 🚀 Quick Start

### 1) Clone and Install
```bash
git clone <your-repo-url>
cd playwright-ai-self-healing-framework
npm install
npx playwright install --with-deps
```

### 2) Start ChromaDB
```bash
cp .env.example .env
npm run chroma:up
```

### 3) Configure OpenAI
Edit `.env`:
```bash
OPENAI_API_KEY=YOUR_KEY
AI_MODE=live
```

> If you don’t want to use OpenAI, set:
```bash
AI_MODE=mock
```

### 4) Run Tests
```bash
npm test
```

### 5) Generate Allure Report
```bash
npm run report:allure
npm run report:open
```

---

## 🧠 Locator DSL (Safe Output Format)
The AI returns one locator line using this DSL:
- `testid=<value>`
- `role=<role>[name="..."]`
- `label=<text>`
- `placeholder=<text>`
- `text=<text>`
- `css=<selector>`

This avoids unsafe `eval()` and keeps healing deterministic.

---

## 🔐 GitHub Actions
Add repository secret:
- `OPENAI_API_KEY`

CI will:
- Start ChromaDB as a service
- Run Playwright tests
- Generate Allure report artifact

---

## 📦 npm Publish Guide
1. Update `package.json`:
   - `name`
   - `version`
   - `repository.url`
2. Login:
```bash
npm login
```
3. Publish:
```bash
npm publish --access public
```

---

## 🔭 Future Extensions (Designed In)
- Multi-agent healing strategies (DOM agent, Visual agent, API agent)
- Flaky detection & autonomous stabilization
- Visual AI (screenshot diff + embedding)
- Autonomous PR creation and healing suggestion bot
- Dashboard integration (React Admin)
- MongoDB or PostgreSQL metadata storage

---

## License
MIT


## 🧾 Allure Attachments (Healing Analytics)
When healing occurs, the framework automatically attaches to the test:
- `healing-*.json` (failed locator, healed locator, confidence, model, retry attempt)
- `healing-*.png` screenshot from the failure/healing attempt

This enables client-ready healing analytics inside Allure.
